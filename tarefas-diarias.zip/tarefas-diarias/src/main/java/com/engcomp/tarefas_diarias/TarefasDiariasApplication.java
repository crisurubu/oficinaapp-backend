package com.engcomp.tarefas_diarias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TarefasDiariasApplication {

	public static void main(String[] args) {
		SpringApplication.run(TarefasDiariasApplication.class, args);
	}

}
