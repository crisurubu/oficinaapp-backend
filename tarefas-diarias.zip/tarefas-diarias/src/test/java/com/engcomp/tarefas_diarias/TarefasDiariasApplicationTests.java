package com.engcomp.tarefas_diarias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TarefasDiariasApplicationTests {

	@Test
	void contextLoads() {
	}

}
